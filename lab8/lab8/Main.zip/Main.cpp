/*
Author:Michael Zuccarino
This program will read a text file of a maximum word count of 128. It will then return an output file with
every word from the input file on a line and the character count next to it.
Input File >> current directory >> "input.txt"
Output file >> current directory >> "output.txt"
*/

#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
using namespace std;

int retrieveIndexOfLowest(const int *scoreList)
{
	int lowestScoreIdx = 0;
	int previousScore = 101;
	for (int idx = 0; idx < 1024; idx++)
	{
		if (scoreList[idx] == 0)
		{
			break;
		}
		else
		{
			if (previousScore > scoreList[idx])
			{
				previousScore = scoreList[idx];
				lowestScoreIdx = idx;
			}
		}
		cout << "LOWEST || prev score is: " << previousScore << ",returned index is: " << lowestScoreIdx << endl;
	}
	return lowestScoreIdx;
}

int retrieveIndexOfHighest(const int *scoreList)
{
	int highestScoreIdx = 0;
	int previousScore = 0;
	for (int idx = 0; idx < 1024; idx++)
	{
		if (scoreList[idx] == 0)
		{
			break;
		}
		else
		{
			if (previousScore < scoreList[idx])
			{
				previousScore = scoreList[idx];
				highestScoreIdx = idx;
			}
		}
		cout << "HIGHEST || prev score is: " << previousScore << ",returned index is: " << highestScoreIdx << endl;
	}
	return highestScoreIdx;
}

int retrieveTestAverage(const int *scoreList)
{
	int scoreTotal = 0;
	int count = 0;
	for (int idx = 0; idx < 1024; idx++)
	{
		if (scoreList[idx] == 0)
		{
			count = idx;
			break;
		}
		scoreTotal += scoreList[idx];
	}
	return scoreTotal / count;
}

int retrieveMedian(const int *scoreList)
{
	// This is my genius O(2N * domain(N)) sort. I think more efficient than traditional compare and 
	// bubble sort functions of O(N^2) :]. Inspired by Hough Transform.
	int highestScoreIdx = 0;
	int previousScore = 0;
	int arrLength = 0;
	int bins[101];
	for (int k = 0; k < 101; k++)
	{
		bins[k] = -1;
	}
	for (int idx = 0; idx < 1024; idx++)
	{
		if (scoreList[idx] == 0)
		{
			break;
		}
		arrLength++;
	}
	for (int idx = 0; idx < arrLength; idx++)
	{
		bins[(scoreList[idx])] = idx;
		cout << "index " << idx << "stored in bin " << (scoreList[idx]) << endl;
	} 
	int idx = 0, counter = 0;
	int ordered[1024] = { 0 };
	while (counter <= 100)
	{
		if (bins[counter] == -1)
		{
			cout << "empty bin at " << counter << endl;
		}
		else
		{
			ordered[idx] = scoreList[bins[counter]];
			cout << "ordered bin row " << idx << "is " << scoreList[bins[counter]] << endl;
			idx++;
		}
		counter++;
	}
	// dump array
	for (int i = 0; i < arrLength; i++)
	{
		cout << "array dump i: " << i << " value: " << ordered[i] << endl;
	}
	int middle = arrLength / 2;
	cout << "middle is: " << middle << endl;
	int median = ordered[middle];
	cout << "median is " << median << endl;
	return median;
}

int main()
{
	// Initialize workspace
	fstream inputFile;
	fstream outputFile;
	inputFile.open("input.txt", ios::in);
	string chunk;
	string studentName[1024] = { "" };
	int studentScores[1024] = { 0 };
	int nameCount = 0, scoreCount = 0;

	cout << "Welcome to the class statistic program!" << endl;
	cout << "Press \"f\" for file input, or \"m\" for manual input: ";
	char inputType;
	bool waitingInput = true;
	while (waitingInput)
	{
		cin >> inputType;
		switch (inputType)
		{
		case 'f':
			waitingInput = false;
			break;
		case 'm':
			waitingInput = false;
			break;
		default:
			cout << "Oops, try again: ";
		}
	}
	outputFile.open("output.txt", ios::out);
	if (inputType == 'f')
	{
		if (inputFile)
		{
			string firstName = "", lastName = "";
			int scoreTemp = 0;

			do
			{

				getline(inputFile, firstName, ' ');
				getline(inputFile, lastName, ' ');
				inputFile >> scoreTemp;
				inputFile.ignore(256, '\n');
				if (!inputFile.eof())
				{
					studentName[nameCount++] = firstName + " " + lastName;
					studentScores[scoreCount++] = scoreTemp;
					cout << "names: " << studentName[(nameCount - 1)] << "... score: " << studentScores[(scoreCount - 1)] << endl;
				}
			} while (!inputFile.eof());

			int lowestIdx = retrieveIndexOfLowest(studentScores);
			cout << "LOWEST || returned index is: " << lowestIdx << endl;

			int highestIdx = retrieveIndexOfHighest(studentScores);
			cout << "HIGHEST || returned index is: " << highestIdx << endl;

			int testAverage = retrieveTestAverage(studentScores);
			cout << "AVERAGE || returned index is: " << testAverage << endl;

			int median = retrieveMedian(studentScores);
			cout << "MEDIAN || returned index is: " << median << endl;

			outputFile << "CLASS REPORT: Lowest: " << studentScores[lowestIdx] << ", Highest: " << studentScores[highestIdx] << ", Average: " << testAverage << ", Median: " << median << endl;
			outputFile << "--STUDENT NAME                SCORE -| COMPARE TO |- LOWEST - HIGHEST - MEAN - MEDIAN -" << endl;
			for (int i = (scoreCount - 1); i >= 0; i--)
			{
				outputFile << studentName[i] << "----------------------" << studentScores[i] << "-----------------" << (i == lowestIdx ? "  yes     " : "  no     ") << (i == highestIdx ? "  yes     " : "  no     ") << (studentScores[i] == testAverage ? "  equal  " : (studentScores[i] <= testAverage ? "  below  " : "  above  ")) << (studentScores[i] == median ? "  equal  " : (studentScores[i] <= median ? "  below  " : "  above  ")) << endl;
			}
		}
	}
	else
	{
		string fullName = "";
		int scoreTemp = 0;
		cout << "Excellent, let's begin! Type the student's name: ";
		cin.ignore(256, '\n');
		getline(cin, fullName, '\n');
		cout << "Now the score: ";
		cin >> scoreTemp;
		studentName[nameCount++] = fullName;
		studentScores[scoreCount++] = scoreTemp;
		cout << "Ok so I have " << studentName[0] << ", and he/she got score: " << studentScores[0] << endl;
		cout << "add more? (y / n)" << endl;
		waitingInput = true;
		while (waitingInput)
		{
			cin >> inputType;
			if ((inputType == 'y') || (inputType == 'n'))
			{
				break;
			}
			cout << "oops, try again" << endl;
		}
		while (inputType == 'y')
		{
			cout << "Type the student's name: ";
			cin.ignore(256, '\n');
			getline(cin, fullName, '\n');
			cout << "Now the score: ";
			cin >> scoreTemp;
			studentName[nameCount++] = fullName;
			studentScores[scoreCount++] = scoreTemp;
			cout << "Ok so I have " << studentName[nameCount - 1] << ", and he/she got score: " << studentScores[scoreCount - 1] << endl;
			cout << "add more? (y / n)" << endl;
			waitingInput = true;
			while (waitingInput)
			{
				cin >> inputType;
				if ((inputType == 'y') || (inputType == 'n'))
				{
					break;
				}
				cout << "oops, try again" << endl;
			}
		}

		int lowestIdx = retrieveIndexOfLowest(studentScores);
		cout << "LOWEST || returned index is: " << lowestIdx << endl;

		int highestIdx = retrieveIndexOfHighest(studentScores);
		cout << "HIGHEST || returned index is: " << highestIdx << endl;

		int testAverage = retrieveTestAverage(studentScores);
		cout << "AVERAGE || returned index is: " << testAverage << endl;

		int median = retrieveMedian(studentScores);
		cout << "MEDIAN || returned index is: " << median << endl;

		outputFile << "CLASS REPORT: Lowest: " << studentScores[lowestIdx] << ", Highest: " << studentScores[highestIdx] << ", Average: " << testAverage << ", Median: " << median << endl;
		outputFile << "--STUDENT NAME                SCORE -| COMPARE TO |- LOWEST - HIGHEST - MEAN - MEDIAN -" << endl;
		for (int i = (scoreCount - 1); i >= 0; i--)
		{
			outputFile << studentName[i] << "----------------------" << studentScores[i] << "-----------------" << (i == lowestIdx ? "  yes     " : "  no     ") << (i == highestIdx ? "  yes     " : "  no     ") << (studentScores[i] == testAverage ? "  equal  " : (studentScores[i] <= testAverage ? "  below  " : "  above  ")) << (studentScores[i] == median ? "  equal  " : (studentScores[i] <= median ? "  below  " : "  above  ")) << endl;
		}
	}
	
	return 0;
}
